import { Message, AttachmentBuilder } from "discord.js";
import { checkAntiVuln, formatBlockedMessage } from "../anti-vuln";
import * as path from "path";
import { logger } from "../../lib/logger";

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

// ─────────────────────────────────────────────────────────────────────────────
// REGEX PATTERNS
// ─────────────────────────────────────────────────────────────────────────────

const FLOORDIV_ASSIGN_RE = /^([ \t]*)((?:[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)*))\s*\/\/=\s*(.+)$/gm;
const CONCAT_ASSIGN_RE = /^([ \t]*)((?:[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)*))\s*\.\.=\s*(.+)$/gm;
const COMPOUND_ASSIGN_RE = /^([ \t]*)((?:[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)*))\s*([+\-*/%^])=\s*(.+)$/gm;
const AND_OP_RE = /\s*&&\s*/g;
const OR_OP_RE = /\s*\|\|\s*/g;
const NOT_OP_RE = /(?<!\w)!(?=[a-zA-Z_(])/g;
const NULL_KW_RE = /\bnull\b/g;
const ELSE_IF_RE = /\belse[ \t]+if\b/g;
const STR_CONCAT_RE = /"((?:[^"\\]|\\.)*)"\s*\.\.\s*"((?:[^"\\]|\\.)*)")"/g;

const LUA_KEYWORDS = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for",
  "function", "goto", "if", "in", "local", "nil", "not", "or",
  "repeat", "return", "then", "true", "until", "while",
]);

// ─────────────────────────────────────────────────────────────────────────────
// HELPER FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

function extractCodeblock(text: string): { code: string; lang: string } | null {
  if (!text) return null;

  let match = text.match(/^```(?:lua|luau)?\n?([\s\S]*?)\n?```$/);
  if (match) return { code: match[1].trim(), lang: "lua" };

  match = text.match(/^```([\s\S]*?)```$/);
  if (match) return { code: match[1].trim(), lang: "lua" };

  return null;
}

function extractFirstUrl(text: string): string | null {
  const match = text.match(/https?:\/\/[^\s"')]+/);
  if (!match) return null;

  let url = match[0];
  url = url.replace(/[\')])+\)$/, "");
  if (url.endsWith(") )()")) url = url.slice(0, -4);
  return url;
}

function getFilenameFromUrl(url: string): string {
  let filename = url.split("/").pop()?.split("?")[0] || "";
  filename = decodeURIComponent(filename);
  return filename && filename.includes(".") ? filename : "script.lua";
}

async function fetchUrl(url: string, timeout = 8000): Promise<Buffer | null> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    const res = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch (err) {
    logger.debug({ err }, "Failed to fetch URL");
    return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LUA COMPATIBILITY FIXES
// ─────────────────────────────────────────────────────────────────────────────

function fixLuaCompat(code: string): string {
  let out = code;

  // Convert assignment operators
  out = out.replace(FLOORDIV_ASSIGN_RE, "$1$2 = $2 // $3");
  out = out.replace(CONCAT_ASSIGN_RE, "$1$2 = $2 .. $3");
  out = out.replace(COMPOUND_ASSIGN_RE, "$1$2 = $2 $3 $4");

  // Convert operators
  out = out.replace(/!=/g, "~=");
  out = out.replace(AND_OP_RE, " and ");
  out = out.replace(OR_OP_RE, " or ");
  out = out.replace(NOT_OP_RE, "not ");
  out = out.replace(NULL_KW_RE, "nil");
  out = out.replace(ELSE_IF_RE, "elseif");

  return out;
}

function stripComments(code: string): string {
  const lines = code.split("\n");
  const result: string[] = [];

  for (const line of lines) {
    const stripped = line.trim();
    if (stripped.startsWith("--")) continue;

    let cleanedLine = line;
    const commentIdx = line.indexOf("--");
    if (commentIdx !== -1) {
      cleanedLine = line.substring(0, commentIdx);
    }

    result.push(cleanedLine);
  }

  return result.join("\n");
}

function foldStringConcat(code: string): string {
  let prev = null;
  while (prev !== code) {
    prev = code;
    code = code.replace(STR_CONCAT_RE, '"$1$2"');
  }
  return code;
}

function collapseBlankLines(code: string): string {
  return code.replace(/\n{3,}/g, "\n\n");
}

function removeTrailingWhitespace(code: string): string {
  return code
    .split("\n")
    .map((line) => line.trimEnd())
    .join("\n");
}

function normalizeCounters(line: string): string {
  return line.replace(/\b([a-z][A-Za-z_]*)\d+\b/g, "$1");
}

function beautifyLua(code: string): string {
  const lines = code.split("\n");
  const output: string[] = [];
  let indent = 0;

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (!line) {
      output.push("");
      continue;
    }

    const match = line.match(/^(\w+)/);
    const firstKw = match ? match[1] : "";

    if (["end", "until"].includes(firstKw)) {
      indent = Math.max(0, indent - 1);
    } else if (["else", "elseif"].includes(firstKw)) {
      indent = Math.max(0, indent - 1);
    }

    output.push("    ".repeat(indent) + line);

    if (["else", "elseif"].includes(firstKw)) {
      indent += 1;
    } else if (["function", "do", "repeat"].includes(firstKw)) {
      indent += 1;
    } else if (["if", "for", "while"].includes(firstKw)) {
      if (/\b(then|do)\s*(?:--.*)?$/.test(line)) indent += 1;
    } else if (firstKw === "then") {
      indent += 1;
    } else if (/\bfunction\b/.test(line) && !/\bend\b\s*(?:--.*)?$/.test(line)) {
      indent += 1;
    }
  }

  return output.join("\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTENT EXTRACTION
// ─────────────────────────────────────────────────────────────────────────────

async function extractContentFromMessage(
  msg: Message
): Promise<{ content: Buffer; filename: string; error: string | null }> {
  // 1. Check codeblock
  const codeblock = extractCodeblock(msg.content);
  if (codeblock) {
    return {
      content: Buffer.from(codeblock.code, "utf-8"),
      filename: "codeblock.lua",
      error: null,
    };
  }

  // 2. Check attachment
  if (msg.attachments.size > 0) {
    const att = msg.attachments.first()!;
    if (!att.name?.match(/\.(lua|luau|txt)$/i)) {
      return { content: Buffer.alloc(0), filename: att.name || "file", error: "Invalid file type" };
    }

    if ((att.size || 0) > MAX_FILE_SIZE) {
      return { content: Buffer.alloc(0), filename: att.name || "file", error: "File too large (max 5MB)" };
    }

    const content = await fetchUrl(att.url);
    if (!content) {
      return { content: Buffer.alloc(0), filename: att.name || "file", error: "Failed to fetch attachment" };
    }

    return { content, filename: att.name || "file", error: null };
  }

  // 3. Check reply
  if (msg.reference) {
    try {
      const repliedTo = await msg.channel.messages.fetch(msg.reference.messageId!);
      return await extractContentFromMessage(repliedTo);
    } catch (err) {
      return { content: Buffer.alloc(0), filename: "reply", error: "Failed to fetch replied message" };
    }
  }

  return {
    content: Buffer.alloc(0),
    filename: "file",
    error: "Provide a codeblock, attachment, or reply to a message with code",
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// LUAU TO LUA CONVERSION
// ─────────────────────────────────────────────────────────────────────────────

function luauToLua53(code: string): string {
  let out = code;

  // continue → goto
  out = out.replace(/\bcontinue\b/g, "goto __continue__");

  // task.wait → coroutine.yield
  out = out.replace(/\btask\.wait\b/g, "coroutine.yield");

  // task.spawn → coroutine.wrap
  out = out.replace(/\btask\.spawn\b/g, "coroutine.wrap");

  // string.split polyfill
  out = out.replace(
    /\bstring\.split\s*\(([^,]+),\s*([^)]+)\)/g,
    (_, s, sep) =>
      `(function(str,d) local t={} for p in str:gmatch("[^"..d.."]+") do t[#t+1]=p end return t end)(${s},${sep})`
  );

  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// COMMAND HANDLERS
// ─────────────────────────────────────────────────────────────────────────────

export async function luaCommand(msg: Message) {
  const { content, filename, error } = await extractContentFromMessage(msg);

  if (error) {
    await msg.reply(error);
    return;
  }

  if (content.length === 0) {
    await msg.reply("Usage: `.l <lua code>` or upload a `.lua` file, or reply to a message containing code.");
    return;
  }

  const rawCode = content.toString("utf-8", 0, Math.min(content.length, 1000000));

  // Anti-vuln check
  const vulv = checkAntiVuln(rawCode);
  if (vulv.blocked) {
    await msg.reply(formatBlockedMessage(vulv));
    return;
  }

  try {
    // Process code
    let processed = luauToLua53(rawCode);
    processed = fixLuaCompat(processed);
    processed = normalizeCounters(processed);
    processed = stripComments(processed);
    processed = foldStringConcat(processed);
    processed = beautifyLua(processed);
    processed = collapseBlankLines(processed);
    processed = removeTrailingWhitespace(processed);

    const output = `-- Converted to Lua 5.3 by Lua Dumper Bot\n${processed}`;

    if (output.length > 1900) {
      const buf = Buffer.from(output, "utf-8");
      const outFilename = `${path.basename(filename, path.extname(filename))}_converted.lua`;
      const att = new AttachmentBuilder(buf, { name: outFilename });
      await msg.reply({ content: "Output is too large — sent as file:", files: [att] });
    } else {
      await msg.reply("```lua\n" + output + "\n```");
    }
  } catch (err) {
    logger.error({ err }, "Error in lua command");
    await msg.reply("❌ Error processing Lua code");
  }
}

export async function beautifyCommand(msg: Message) {
  const { content, filename, error } = await extractContentFromMessage(msg);

  if (error) {
    await msg.reply(error);
    return;
  }

  if (content.length === 0) {
    await msg.reply("Usage: `.bf <lua code>` or upload a file");
    return;
  }

  try {
    const code = content.toString("utf-8");
    const beautified = beautifyLua(code);

    if (beautified.length > 1900) {
      const buf = Buffer.from(beautified, "utf-8");
      const outFilename = `${path.basename(filename, path.extname(filename))}_beautified.lua`;
      const att = new AttachmentBuilder(buf, { name: outFilename });
      await msg.reply({ content: "Beautified code:", files: [att] });
    } else {
      await msg.reply("```lua\n" + beautified + "\n```");
    }
  } catch (err) {
    logger.error({ err }, "Error in beautify command");
    await msg.reply("❌ Error beautifying code");
  }
}

export async function getCommand(msg: Message) {
  const args = msg.content.slice(4).trim();
  let url = extractFirstUrl(args);

  if (!url) {
    const { content, filename, error } = await extractContentFromMessage(msg);
    if (error) {
      await msg.reply(error);
      return;
    }

    if (content.length === 0) {
      await msg.reply("Usage: `.get <url>` or upload a file");
      return;
    }

    const buf = Buffer.from(content);
    const att = new AttachmentBuilder(buf, { name: filename });
    await msg.reply({ files: [att] });
    return;
  }

  // Fetch from URL
  try {
    const fetchedContent = await fetchUrl(url);
    if (!fetchedContent) {
      await msg.reply("❌ Failed to fetch URL");
      return;
    }

    if (fetchedContent.length > MAX_FILE_SIZE) {
      await msg.reply("❌ File too large (max 5MB)");
      return;
    }

    const filename = getFilenameFromUrl(url);
    const att = new AttachmentBuilder(fetchedContent, { name: filename });
    await msg.reply({ content: url, files: [att] });
  } catch (err) {
    logger.error({ err }, "Error in get command");
    await msg.reply("❌ Error fetching URL");
  }
}

export async function helpCommand(msg: Message) {
  const helpText = `**Lua Dumper Bot Commands**

\`.l [code/file/url]\` — Convert & beautify Lua/Luau code
\`.bf [code/file/url]\` — Beautify Lua code
\`.get [url]\` — Download file from URL
\`.help\` — Show this message

**Usage:**
- Attach a file, provide code in a codeblock, provide a URL, or reply to a message
- All commands support Lua and Luau syntax`;

  await msg.reply(helpText);
}
